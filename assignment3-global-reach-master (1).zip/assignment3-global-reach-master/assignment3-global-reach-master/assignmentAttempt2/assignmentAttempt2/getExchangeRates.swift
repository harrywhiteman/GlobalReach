//
//  getExchangeRates.swift
//  assignmentAttempt2
//
//  Created by Harry Whiteman on 19/5/21.
//  Copyright © 2021 Amani MOUSSA. All rights reserved.
//

import Foundation

import UIKit

struct ExchangeRates: Codable {
    var rates: [String: Double];
}

func fetchRates(completionHandler: @escaping (ExchangeRates) -> Void) {
    let url = URL(string: "https://api.frankfurter.app/latest?from=AUD&to=USD,GBP,EUR,CNY")!
    
    let task = URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
        if let error = error {
            print("Error fetching rates: \(error)")
            return
        }
    
        guard let httpResponse =  response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            print("Error with the response: \(String(describing: response))")
            return
        }
        
        let decoder = JSONDecoder()
        
        
        if let data = data, let ratesSummary = try? decoder.decode(ExchangeRates.self, from: data) {
            completionHandler(ratesSummary)
            
        }
    })
    task.resume()
    
    
}


