//
//  ThirdViewController.swift
//  assignmentAttempt2
//
//  Created by Amani MOUSSA on 18/5/21.
//  Copyright © 2021 Amani MOUSSA. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {
  
    @IBSegueAction func china(_ coder: NSCoder) -> ThirdViewController? {
        return ThirdViewController(coder: coder)
    }
    
    
    @IBOutlet weak var ExchangeButton: UIButton!
    @IBOutlet weak var From: UITextField!
    
    @IBOutlet weak var Amount: UITextField!
  
    @IBOutlet weak var ResultLabel: UILabel!
    @IBOutlet weak var TO: UITextField!
    
    @IBOutlet weak var textBox: UITextField!
    var currencyFrom = ""
    var currencyTo = ""
    var amount : Int = 1
    var firstValue = ""
    var secondValue = ""
    var temp = ""
    var to = ""
    var currencyCode : [String] = []
    var currencyName : [String] = []
    
    var country = ["Australia (AUD)", "USA (USD)", "Britain (GPB)", "Canada (CAD)", "Japan (JPY)", "China (CNY)", "France (EURO)", "Italy (EURO)", "Germany (EURO)", "South Africa (ZAR)", "Spain (EURO)"]
       
       //var pickerView = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        retieveCurrencyCode()
        self.From.text = "AUD";
        self.TO.text = self.to;
        
       // self.ExchangeButton.image = UIImage(named: "exch");
       //pickerView.delegate = self
       //pickerView.dataSource = self

        //textBox.inputView = pickerView
        // Do any additional setup after loading the view.
    }
    
    //button to perform conversion
    @IBAction func Convert(_ sender: Any) {
        if let currencyFrom =  From.text{
            if let currencyTo = TO.text{
                if let amount = Amount.text{
                    checkValidation(from : currencyFrom, to : currencyTo, amt : amount)
                  
                    fetchData(from : currencyFrom, to : currencyTo, amt : amount)
                }
                
                
            }
            
            
        }
      
    }
    
    //button to interchange the textbox values
    @IBAction func ValueExchange(_ sender: Any) {
        if let firstValue = From.text{
            if let secondValue = TO.text{
                temp = firstValue
                self.firstValue = secondValue
                self.secondValue = temp
            }
        }
        changeTextFields(first: firstValue, second: secondValue)
    }
    
    //function to fetch currency data from API
    func fetchData(from : String, to: String, amt: String){
       
        
        let mainURL = "https://api.frankfurter.app/latest"
        
        let urlString = "\(mainURL)?amount=\(amt)&from=\(from)&to=\(to)"
        retrieveData(url : urlString , currencyto : to)
    }
    
    //function to set label
    func changeLabel(val : Double) {
        
        DispatchQueue.main.async {
            self.ResultLabel.text = String(val)
        }
    }
    
    //function to set textfields
    func changeTextFields(first: String, second: String){
        DispatchQueue.main.async {
            self.From.text = self.firstValue
            self.TO.text = self.secondValue
        }
    }
    
    //function for data validation
    func checkValidation(from : String, to: String, amt: String){
        if from != ""{
            if to != ""{
                if amt != ""{
                    if self.currencyCode.contains(from)
                    {
                        if self.currencyCode.contains(to)
                        {
                            var money = Int(amt)
                            if money == nil{
                                self.showToast(message: "Incorrect Entery!! amount must be integer", font: .systemFont(ofSize: 12.0))
                            }
                        }
                        else{
                            self.showToast(message: "Incorrect Entery!! Please enter currency Code", font: .systemFont(ofSize: 12.0))
                        }
                    }
                    else{
                        self.showToast(message: "Incorrect Entery!! Please enter currency Code", font: .systemFont(ofSize: 12.0))
                    }
                }
                else{
                    self.showToast(message: "Please enter the Amount", font: .systemFont(ofSize: 12.0))
                    
                }
            }
            else{
                self.showToast(message: "Please enter the Currency To ", font: .systemFont(ofSize: 12.0))
                }
        }
        else{
        self.showToast(message: "Please enter Currency From", font: .systemFont(ofSize: 12.0))
       }
    }
    
    
    //retrieve data from API
    func retrieveData(url : String, currencyto : String){
        let urlString = url
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            // step 3: give URLSession a task
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let content = data{
                    do{
                        let myJson = try JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        if let rates = myJson["rates"] as? NSDictionary{
                            for (key, value) in rates{
                                if(key as! String == currencyto){
                                    print(value)
                                    //self.ResultLabel.text = value as? String
                                    self.changeLabel(val : value as! Double);
                                }
                            }
                        }
                        
                    }
                    catch{
                        self.showToast(message: "Data Not Found", font: .systemFont(ofSize: 12.0))
                    }
                }
            }
            
            // step 4: start a task
            task.resume()
        }
        
    }
    
    //retrieve currrency code and name from API
    func retieveCurrencyCode(){
        let urlString = "https://api.frankfurter.app/currencies"
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            // step 3: give URLSession a task
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let content = data{
                    do{
                        let myJson = try JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        if let code = myJson as? NSDictionary{
                            for (key , value) in code{
                                self.currencyCode.append(key as! String)
                                self.currencyName.append(value as! String)
                            }
                        }
                        
                    }
                    catch{
                        self.showToast(message: "Data Not Found", font: .systemFont(ofSize: 12.0))
                    }
                }
            }
            
            // step 4: start a task
            task.resume()
        }
        
    }
        
    }
    
    
    

extension UIViewController {
//function to show alert
func showToast(message : String, font: UIFont) {

    let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 150 , y: self.view.frame.size.height-150, width: 300, height: 35))
    toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    toastLabel.textColor = UIColor.white
    toastLabel.font = font
    toastLabel.textAlignment = .center;
    toastLabel.text = message
    toastLabel.alpha = 1.0
    toastLabel.layer.cornerRadius = 10;
    toastLabel.clipsToBounds  =  true
    self.view.addSubview(toastLabel)
    UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
         toastLabel.alpha = 0.0
    }, completion: {(isCompleted) in
        toastLabel.removeFromSuperview()
    })
} }/*extension FourthViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return country.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return country[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        textBox.text = country[row]
        textBox.resignFirstResponder()
    }
    }*/
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


