//
//  FourthViewController.swift
//  assignmentAttempt2
//
//  Created by Amani MOUSSA on 18/5/21.
//  Copyright © 2021 Amani MOUSSA. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    
    @IBOutlet weak var chinaLabel: UILabel!
    
    @IBOutlet weak var franceLabel: UILabel!
    
    @IBOutlet weak var usaLabel: UILabel!
    
    
    @IBOutlet weak var italyLabel: UILabel!
    
    @IBOutlet weak var chinaUpDown: UIImageView!
    
    
    @IBOutlet weak var franceUpDown: UIImageView!
    
    @IBOutlet weak var usaUpDown: UIImageView!
    
    
    @IBOutlet weak var italyUpDown: UIImageView!
    
    
    
    
    var chinaValue = 0.00;
    let ausValue = 1.00;
    var franceValue = 0.00;
    var italyValue = 0.00;
    var usaValue = 0.00;
    var err = "";
    var usaUp = false;
    var usaDown = false;
    var chinaUp = false;
    var chinaDown = false;
    var italyUp = false;
    var italyDown = false;
    var franceUp = false;
    var franceDown = false;
    var usaDifferenceDouble = 0.00;
    var euroDifferenceDouble = 0.00;
    var chinaDifferenceDouble = 0.00;
    
    
    struct ExchangeRates: Codable {
        var rates: [String: Double];
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var timer = Timer();
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(fetchRates), userInfo: nil, repeats: true)

        
        
        
        
        
       }
    
    func changeLabel() {
        
        DispatchQueue.main.async {
            
            self.chinaLabel.text = String("¥\(self.chinaValue)");
            if(self.chinaUp) {
                self.chinaUpDown.image = UIImage(named: "up");
            } else if(self.chinaDown) {
                self.chinaUpDown.image = UIImage(named: "down");
            }
            
            self.usaLabel.text = String("$\(self.usaValue)");
            if(self.usaUp) {
                self.usaUpDown.image = UIImage(named: "up");
                // self.usaDifference.text = String(self.usaDifferenceDouble);
            } else if(self.usaDown) {
                self.usaUpDown.image = UIImage(named: "down");
            }
            
            self.italyLabel.text = String("€\(self.italyValue)");
            if(self.italyUp) {
                self.italyUpDown.image = UIImage(named: "up");
            } else if(self.italyDown) {
                self.italyUpDown.image = UIImage(named: "down");
            }
            
            self.franceLabel.text = String("€\(self.franceValue)");
            if(self.franceUp) {
                self.franceUpDown.image = UIImage(named: "up");
            } else if(self.franceDown) {
                self.franceUpDown.image = UIImage(named: "down");
            }
        }
    }
    
    @objc func fetchRates() {
        let url = URL(string: "https://api.frankfurter.app/latest?from=AUD&to=USD,GBP,EUR,CNY")!
        
        let task = URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
            if let error = error {
                print("Error fetching rates: \(error)")
                return
            }
        
            guard let httpResponse =  response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                print("Error with the response: \(String(describing: response))")
                return
            }
            
            let decoder = JSONDecoder()
            
            
            if let data = data, let ratesSummary = try? decoder.decode(ExchangeRates.self, from: data) {
                
            
                for rate in ratesSummary.rates {
                    switch (rate.key) {
                    case "USD":
                        self.usaDifferenceDouble = self.getDifference(prev: self.usaValue, current: rate.value)
                        /*if(self.usaDifferenceDouble < 0.00) {
                            self.usaDown = true;
                            
                        } else if(self.usaDifferenceDouble > 0.00) {
                            self.usaUp = true;
                        }*/
                        self.usaValue = rate.value;
                        
                    case "EUR":
                        self.euroDifferenceDouble = self.getDifference(prev: self.italyValue, current: rate.value)
                        /*if(self.euroDifferenceDouble < 0.00) {
                            self.italyDown = true;
                            self.franceDown = true;
                            
                        } else if(self.euroDifferenceDouble > 0.00) {
                            self.italyUp = true;
                            self.franceUp = true;
                        }*/
                        self.italyValue = rate.value;
                        self.franceValue = rate.value;
                    case "CNY":
                        self.chinaDifferenceDouble = self.getDifference(prev: self.chinaValue, current: rate.value)
                        /*if(self.chinaDifferenceDouble < 0.00) {
                            self.chinaDown = true;
                            
                        } else if(self.chinaDifferenceDouble > 0.00) {
                            self.chinaUp = true;
                        }*/
                        self.chinaValue = rate.value;
                    default:
                        self.err = "present";
                    }
                }
                
                self.changeLabel();
                
            
            
            }
        })
        task.resume()
        
        
    }
    
        

    
    func getDifference(prev: Double, current: Double) -> Double {
        return prev - current;
    }
    }
    
    
