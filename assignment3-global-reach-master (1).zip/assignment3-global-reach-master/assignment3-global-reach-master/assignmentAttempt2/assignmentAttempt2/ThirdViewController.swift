//
//  SecondViewController.swift
//  assignmentAttempt2
//
//  Created by Amani MOUSSA on 18/5/21.
//  Copyright © 2021 Amani MOUSSA. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    @IBOutlet weak var chinaButton: UIButton!
    @IBOutlet weak var franceButton: UIButton!
    @IBOutlet weak var USAButton: UIButton!
    @IBOutlet weak var italyButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "china" {
        let VC = segue.destination as? FourthViewController
        VC?.to = "CNY"
          }
    
    if segue.identifier == "france" {
        let VC = segue.destination as? FourthViewController
        VC?.to = "EUR"
          }

    if segue.identifier == "italy" {
        let VC = segue.destination as? FourthViewController
        VC?.to = "EUR"
          }

    if segue.identifier == "USA" {
        let VC = segue.destination as? FourthViewController
        VC?.to = "USD"
          }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
